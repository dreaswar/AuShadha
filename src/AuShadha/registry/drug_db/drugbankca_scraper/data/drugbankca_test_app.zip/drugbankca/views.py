# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.http import Http404, HttpResponse

from zipfile import ZipFile
from random import sample

from drugbankca.models import DrugBankCaDrugs


NSAMPLES = 20
LNK = '<a href="/drugbankca/{}">{}</a></br></br>'

BASE = '''
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title> Drugbank Test App </title>
    <link rel="stylesheet" href="/static/style.css" type="text/css">
</head>
<body>
    {}
</body>
</html>
'''

with open('../drugbankca_xml_ids.txt', 'rbU') as f:
    drugbank_ids = f.read().splitlines()


get_drug_id   = lambda drug_name: DrugBankCaDrugs.objects.get(drug_name = drug_name).drug_id
get_drug_name = lambda drug_id: DrugBankCaDrugs.objects.get(drug_id = drug_id).drug_name

def open_drug_table(drug_id):
    try:
        z = ZipFile('data/drugbankca_tables.zip')
        f = z.open(drug_id)
        table_html = f.read()
        f.close()
        z.close()
        return table_html
    except:
        return "Error: No zip or %s not in zip" % drug_id
        
def render_random_sample(request):
    samples = (get_drug_name(drug_id) for drug_id in sample(drugbank_ids, NSAMPLES))
    sample_links = '\n'.join(LNK.format(drug_name, drug_name) for drug_name in samples)
    sample_html = "<b>Choose a drug below (refresh for new sample list)</b></br></br>" + sample_links
    return HttpResponse(sample_html)
    
def render_drug_table(request, drug_name):
    try:
        drug_id = get_drug_id(drug_name)
    except(DrugBankCaDrugs.DoesNotExist):
        raise Http404("ERROR! DrugbankCA does not contain: " + drug_name)
    return HttpResponse(BASE.format(open_drug_table(drug_id)))


