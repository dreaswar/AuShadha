# -*- coding: utf-8 -*-
from django.conf.urls import patterns, include, url

from django.contrib import admin
admin.autodiscover()

from views import render_random_sample, render_drug_table

urlpatterns = patterns('',
    url(r'^$', render_random_sample),
    url(r'^drugbankca/(?P<drug_name>.*)$', render_drug_table, name='render_drug_table'),
    url(r'^admin/', include(admin.site.urls)),
)
