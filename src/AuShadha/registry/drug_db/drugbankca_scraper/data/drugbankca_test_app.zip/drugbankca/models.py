# -*- coding: utf-8 -*-
from django.db import models

class DrugBankCaDrugs(models.Model):
    '''Drugbank Name/ID Mapping'''

    drug_name = models.TextField('Drug Name', max_length=1000, primary_key=True)
    drug_id = models.TextField('Drug ID', max_length=7, null=False, blank=False)

    #def __unicode__(self):
    def __str__(self):
        # In reverse because of possibly very long names
        return "%s: %s" % (self.drug_name, self.drug_id)

    class Meta:
        verbose_name = 'DrugbankCA Drug'
        verbose_name_plural = "DrugbankCA Drugs"
        ordering = ['drug_name', 'drug_id']

