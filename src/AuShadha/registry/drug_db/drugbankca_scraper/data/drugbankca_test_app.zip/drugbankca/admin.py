# -*- coding: utf-8 -*-
from drugbankca.models import *
from django.contrib import admin


class DrugBankCaDrugsAdmin(admin.ModelAdmin):
    list_display = ['drug_name', 'drug_id']


admin.site.register(DrugBankCaDrugs, DrugBankCaDrugsAdmin)
