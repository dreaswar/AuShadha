#!/usr/bin/env bash

# Freaky linking ahoy!...

rm -f drugbankca
ln -s . drugbankca

#rm -f fixtures/DrugBankCaDrugs.json.gz
#ln -s ../../DrugBankCaDrugs.json.gz fixtures/DrugBankCaDrugs.json.gz

rm -f data/drugbankca_tables.zip
ln -s ../../drugbankca_tables.zip data/drugbankca_tables.zip

rm -f drugbankca.db
python manage.py syncdb --no-initial-data

python manage.py loaddata ../DrugBankCaDrugs.json.gz
python manage.py runserver

echo "Simply delete whole directory when not needed."

